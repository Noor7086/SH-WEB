# Services Component

A standalone, professional Services component built with React and Bootstrap. This component features animated backgrounds, 3D card effects, and responsive design.

## Features

- **Animated Background**: Gradient overlays, floating bubbles, and moving lines
- **3D Card Effects**: Interactive service cards with hover animations
- **Responsive Design**: Mobile-friendly layout
- **Professional Styling**: Modern UI with glassmorphism effects
- **Interactive Elements**: Hover effects and smooth transitions

## Installation

1. Install dependencies:
```bash
npm install react react-bootstrap react-icons
```

2. Import the component:
```jsx
import Services from './Services';
import './Services.css';
```

## Usage

```jsx
import React from 'react';
import Services from './Services';
import './Services.css';

function App() {
  return (
    <div className="App">
      <Services />
    </div>
  );
}

export default App;
```

## Dependencies

- **React**: ^18.2.0
- **React Bootstrap**: ^2.9.0
- **React Icons**: ^4.12.0

## Component Structure

- `Services.jsx` - Main component file
- `Services.css` - All necessary CSS animations and styles
- `package.json` - Dependencies and metadata
- `README.md` - This documentation

## Customization

The component includes 6 predefined services:
1. Custom Software Development
2. Mobile App Development
3. Cloud Solutions
4. Digital Transformation
5. Cybersecurity
6. IT Consulting

You can modify the `services` array in `Services.jsx` to customize the content.

## Styling

All styles are contained in `Services.css` including:
- Keyframe animations
- Hover effects
- Responsive breakpoints
- 3D transformations

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

MIT License
