import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { 
  FaCode, 
  FaMobile, 
  FaCloud, 
  FaChartLine, 
  FaShieldAlt, 
  FaCogs,
  FaArrowRight,
  FaRocket,
  FaCheckCircle
} from 'react-icons/fa';
import './Services.css';

const Services = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const services = [
    {
      icon: <FaCode className="display-4" style={{ color: '#667eea' }} />,
      title: "Custom Software Development",
      description: "Tailored solutions designed specifically for your business needs. From web applications to enterprise software, we build scalable and robust systems.",
      features: ["Full-stack Development", "API Integration", "Database Design", "Performance Optimization"],
      gradient: "linear-gradient(135deg, #f8f9ff 0%, #e8f2ff 100%)"
    },
    {
      icon: <FaMobile className="display-4" style={{ color: '#28a745' }} />,
      title: "Mobile App Development",
      description: "Native and cross-platform mobile applications that deliver exceptional user experiences across iOS and Android platforms.",
      features: ["iOS Development", "Android Development", "React Native", "Flutter Apps"],
      gradient: "linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%)"
    },
    {
      icon: <FaCloud className="display-4" style={{ color: '#17a2b8' }} />,
      title: "Cloud Solutions",
      description: "Scalable cloud infrastructure and migration services to optimize your business operations and reduce costs.",
      features: ["AWS/Azure/GCP", "Cloud Migration", "DevOps", "Serverless Architecture"],
      gradient: "linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%)"
    },
    {
      icon: <FaChartLine className="display-4" style={{ color: '#ffc107' }} />,
      title: "Digital Transformation",
      description: "Transform your business processes with cutting-edge digital solutions that drive growth and efficiency.",
      features: ["Process Automation", "Data Analytics", "AI Integration", "Business Intelligence"],
      gradient: "linear-gradient(135deg, #fffbf0 0%, #fff5e6 100%)"
    },
    {
      icon: <FaShieldAlt className="display-4" style={{ color: '#dc3545' }} />,
      title: "Cybersecurity",
      description: "Comprehensive security solutions to protect your digital assets and ensure compliance with industry standards.",
      features: ["Security Audits", "Penetration Testing", "Compliance", "Incident Response"],
      gradient: "linear-gradient(135deg, #fff5f5 0%, #ffe6e6 100%)"
    },
    {
      icon: <FaCogs className="display-4" style={{ color: '#6c757d' }} />,
      title: "IT Consulting",
      description: "Strategic technology consulting to help you make informed decisions and achieve your business objectives.",
      features: ["Technology Strategy", "Architecture Design", "Project Management", "Team Training"],
      gradient: "linear-gradient(135deg, #f8f9fa 0%, #f1f3f4 100%)"
    }
  ];

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="pb-5 position-relative overflow-hidden" style={{ margin: 0, paddingTop: 0 }}>
      {/* Animated Background */}
      <div className="animated-bg position-absolute w-100 h-100" style={{
        top: 0,
        left: 0,
        zIndex: -1
      }}>
        {/* Base Gradient */}
        <div className="bg-layer base-gradient" style={{
          position: 'absolute',
          top: '-120px',
          left: 0,
          width: '100%',
          height: 'calc(100% + 120px)',
          background: 'linear-gradient(135deg, #fafbfc 0%, #e8ecf0 100%)',
          transform: `translateY(${scrollY * 0.05}px)`
        }}></div>

        {/* Animated Gradient Overlay */}
        <div className="bg-layer animated-gradient" style={{
          position: 'absolute',
          top: '-120px',
          left: 0,
          width: '100%',
          height: 'calc(100% + 120px)',
          background: 'linear-gradient(45deg, rgba(102,126,234,0.1) 0%, rgba(118,75,162,0.1) 25%, rgba(240,147,251,0.1) 50%, rgba(102,126,234,0.1) 75%, rgba(118,75,162,0.1) 100%)',
          backgroundSize: '400% 400%',
          animation: 'gradientShift 15s ease infinite',
          opacity: 0.6
        }}></div>

        {/* Floating Bubbles */}
        <div className="bg-layer bubbles-layer" style={{
          position: 'absolute',
          top: '-120px',
          left: 0,
          width: '100%',
          height: 'calc(100% + 120px)',
          transform: `translateY(${scrollY * 0.1}px)`
        }}>
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className="floating-bubble"
              style={{
                position: 'absolute',
                width: `${Math.random() * 60 + 20}px`,
                height: `${Math.random() * 60 + 20}px`,
                background: `rgba(${Math.random() * 100 + 100}, ${Math.random() * 100 + 150}, ${Math.random() * 100 + 200}, 0.1)`,
                borderRadius: '50%',
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `bubbleFloat ${Math.random() * 20 + 15}s linear infinite`,
                animationDelay: `${Math.random() * 10}s`,
                backdropFilter: 'blur(5px)',
                border: '1px solid rgba(255,255,255,0.2)'
              }}
            ></div>
          ))}
        </div>

        {/* Moving Lines */}
        <div className="bg-layer lines-layer" style={{
          position: 'absolute',
          top: '-120px',
          left: 0,
          width: '100%',
          height: 'calc(100% + 120px)',
          transform: `translateY(${scrollY * 0.08}px)`
        }}>
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="moving-line"
              style={{
                position: 'absolute',
                width: '2px',
                height: `${Math.random() * 100 + 50}px`,
                background: 'linear-gradient(to bottom, transparent, rgba(102,126,234,0.3), transparent)',
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `lineMove ${Math.random() * 25 + 20}s linear infinite`,
                animationDelay: `${Math.random() * 15}s`
              }}
            ></div>
          ))}
        </div>

        {/* Subtle Pattern */}
        <div className="bg-layer pattern-layer" style={{
          position: 'absolute',
          top: '-120px',
          left: 0,
          width: '100%',
          height: 'calc(100% + 120px)',
          background: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Cdefs%3E%3Cpattern id=\'dots\' width=\'30\' height=\'30\' patternUnits=\'userSpaceOnUse\'%3E%3Ccircle cx=\'15\' cy=\'15\' r=\'1\' fill=\'rgba(102,126,234,0.1)\'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width=\'100\' height=\'100\' fill=\'url(%23dots)\'/%3E%3C/svg%3E")',
          opacity: 0.4,
          transform: `translateY(${scrollY * 0.03}px)`
        }}></div>
      </div>

      <Container className="pt-5 pb-5 position-relative" style={{ zIndex: 1 }}>
        <Row className="text-center mb-5">
          <Col lg={8} className="mx-auto" data-aos="fade-up">
            <span className="badge px-4 py-3 fw-bold mb-3" style={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              fontSize: '0.9rem'
            }}>
              <FaRocket className="me-2" />
              Our Services
            </span>
            <h2 className="display-5 fw-bold mb-4">
              Scale Your Business with Our 
              <span style={{ 
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}> Comprehensive Solutions</span>
            </h2>
            <p className="lead text-muted fs-5">
              We provide end-to-end software solutions that help businesses grow, 
              innovate, and stay ahead of the competition. Let us be your technology partner.
            </p>
          </Col>
        </Row>

        <Row className="g-5 mb-5">
          {services.map((service, index) => (
            <Col lg={4} md={6} key={index} data-aos="fade-up" data-aos-delay={index * 100}>
              <div className="service-card-wrapper" style={{
                perspective: '1200px',
                height: '100%',
                position: 'relative'
              }}>
                {/* 3D Card Container */}
                <div className="service-card-3d" style={{
                  transform: `translateY(${scrollY * 0.02}px)`,
                  transition: 'all 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
                  cursor: 'pointer',
                  height: '100%',
                  position: 'relative'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-30px) rotateX(10deg) rotateY(10deg) scale(1.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0) rotateX(0deg) rotateY(0deg) scale(1)';
                }}>
                  
                  {/* Main Card */}
                  <div className="service-card-main" style={{
                    background: 'linear-gradient(145deg, rgba(255,255,255,0.98) 0%, rgba(255,255,255,0.95) 100%)',
                    borderRadius: '24px 24px 24px 24px',
                    overflow: 'visible',
                    boxShadow: '0 30px 100px rgba(0,0,0,0.15), 0 0 0 1px rgba(255,255,255,0.3), inset 0 1px 0 rgba(255,255,255,0.4)',
                    backdropFilter: 'blur(30px)',
                    border: '3px solid rgba(255,255,255,0.4)',
                    position: 'relative',
                    minHeight: '520px',
                    display: 'flex',
                    flexDirection: 'column',
                    transition: 'all 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderRadius = '28px 28px 28px 28px';
                    e.currentTarget.style.transform = 'translateY(-8px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderRadius = '24px 24px 24px 24px';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}>
                    
                    {/* Premium Background Layers */}
                    <div className="card-bg-layer-1" style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      background: `linear-gradient(135deg, ${service.gradient.replace('linear-gradient(135deg, ', '').replace(' 100%)', '')} 0%, rgba(255,255,255,0.05) 100%)`,
                      opacity: 0.15,
                      transition: 'opacity 0.8s ease'
                    }}></div>
                    
                    <div className="card-bg-layer-2" style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      background: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Cdefs%3E%3Cpattern id=\'hexagon\' width=\'20\' height=\'20\' patternUnits=\'userSpaceOnUse\'%3E%3Cpolygon points=\'10,2 18,6 18,14 10,18 2,14 2,6\' fill=\'none\' stroke=\'rgba(102,126,234,0.1)\' stroke-width=\'0.5\'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width=\'100\' height=\'100\' fill=\'url(%23hexagon)\'/%3E%3C/svg%3E")',
                      opacity: 0.3,
                      animation: 'patternMove 25s linear infinite'
                    }}></div>

                    {/* Floating Elements */}
                    <div className="floating-elements" style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      pointerEvents: 'none',
                      zIndex: 1
                    }}>
                      {[...Array(8)].map((_, i) => (
                        <div
                          key={i}
                          className="floating-element"
                          style={{
                            position: 'absolute',
                            width: `${Math.random() * 6 + 4}px`,
                            height: `${Math.random() * 6 + 4}px`,
                            background: `linear-gradient(45deg, ${service.gradient.replace('linear-gradient(135deg, ', '').replace(' 100%)', '')} 0%, transparent 100%)`,
                            borderRadius: '50%',
                            left: `${Math.random() * 100}%`,
                            top: `${Math.random() * 100}%`,
                            animation: `floatElement ${Math.random() * 4 + 3}s ease-in-out infinite`,
                            animationDelay: `${Math.random() * 3}s`,
                            filter: 'blur(1px)'
                          }}
                        ></div>
                      ))}
                    </div>

                    {/* Premium Header Section */}
                    <div className="service-header-premium" style={{
                      background: `linear-gradient(135deg, ${service.gradient.replace('linear-gradient(135deg, ', '').replace(' 100%)', '')} 0%, rgba(255,255,255,0.2) 100%)`,
                      padding: '25px 25px',
                      textAlign: 'center',
                      position: 'relative',
                      overflow: 'hidden',
                      borderBottom: '3px solid rgba(255,255,255,0.4)',
                      borderTopLeftRadius: '24px',
                      borderTopRightRadius: '24px',
                      borderBottomLeftRadius: '12px',
                      borderBottomRightRadius: '12px'
                    }}>
                      
                      {/* Animated Geometric Patterns */}
                      <div className="geometric-patterns" style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        opacity: 0.2
                      }}>
                        <div style={{
                          position: 'absolute',
                          top: '20%',
                          right: '10%',
                          width: '60px',
                          height: '60px',
                          background: 'linear-gradient(45deg, rgba(255,255,255,0.3), transparent)',
                          borderRadius: '50%',
                          animation: 'rotate 15s linear infinite'
                        }}></div>
                        <div style={{
                          position: 'absolute',
                          bottom: '20%',
                          left: '15%',
                          width: '40px',
                          height: '40px',
                          background: 'linear-gradient(45deg, rgba(255,255,255,0.2), transparent)',
                          borderRadius: '50%',
                          animation: 'rotate 20s linear infinite reverse'
                        }}></div>
                      </div>
                      
                      {/* Premium Shimmer Effect */}
                      <div className="premium-shimmer" style={{
                        position: 'absolute',
                        top: 0,
                        left: '-100%',
                        width: '100%',
                        height: '100%',
                        background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)',
                        animation: 'premiumShimmer 4s ease-in-out infinite'
                      }}></div>

                      <div className="position-relative" style={{ zIndex: 3 }}>
                        {/* Ultra Premium Icon Container */}
                        <div className="icon-container-ultra" style={{
                          display: 'inline-block',
                          padding: '18px',
                          borderRadius: '20px',
                          background: 'rgba(255,255,255,0.3)',
                          backdropFilter: 'blur(20px)',
                          border: '3px solid rgba(255,255,255,0.5)',
                          transition: 'all 0.6s ease',
                          position: 'relative',
                          overflow: 'hidden',
                          boxShadow: '0 15px 40px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.4)',
                          marginBottom: '15px'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderRadius = '24px';
                          e.currentTarget.style.transform = 'scale(1.05)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderRadius = '20px';
                          e.currentTarget.style.transform = 'scale(1)';
                        }}>
                          {/* Icon Glow Rings */}
                          <div className="icon-glow-ring-1" style={{
                            position: 'absolute',
                            top: '50%',
                            left: '50%',
                            width: '120%',
                            height: '120%',
                            background: 'radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%)',
                            transform: 'translate(-50%, -50%)',
                            borderRadius: '50%',
                            animation: 'iconPulse 3s ease-in-out infinite'
                          }}></div>
                          <div className="icon-glow-ring-2" style={{
                            position: 'absolute',
                            top: '50%',
                            left: '50%',
                            width: '140%',
                            height: '140%',
                            background: 'radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)',
                            transform: 'translate(-50%, -50%)',
                            borderRadius: '50%',
                            animation: 'iconPulse 3s ease-in-out infinite 0.5s'
                          }}></div>
                          
                          <div style={{ position: 'relative', zIndex: 2 }}>
                            {React.cloneElement(service.icon, {
                              style: { 
                                ...service.icon.props.style,
                                fontSize: '2rem',
                                filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.2))'
                              }
                            })}
                          </div>
                        </div>
                
                        {/* Premium Title */}
                        <h3 className="fw-bold mb-0" style={{
                          background: 'linear-gradient(135deg, #1e293b 0%, #475569 50%, #64748b 100%)',
                          WebkitBackgroundClip: 'text',
                          WebkitTextFillColor: 'transparent',
                          backgroundClip: 'text',
                          fontSize: '1.2rem',
                          letterSpacing: '0.5px',
                          textShadow: '0 2px 4px rgba(0,0,0,0.1)'
                        }}>
                          {service.title}
                        </h3>
                      </div>
                    </div>
                    
                    {/* Premium Body Section */}
                    <div className="service-body-premium" style={{ 
                      background: 'rgba(255,255,255,0.95)',
                      position: 'relative',
                      zIndex: 2,
                      padding: '25px 25px 20px 25px',
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      overflow: 'visible',
                      borderBottomLeftRadius: '24px',
                      borderBottomRightRadius: '24px'
                    }}>
                      {/* Premium Description */}
                      <p className="text-muted mb-3 fs-6" style={{ 
                        lineHeight: '1.6',
                        fontWeight: '500',
                        fontSize: '0.95rem'
                      }}>
                        {service.description}
                      </p>
                      
                      {/* Ultra Premium Features List */}
                      <div className="mb-3" style={{ flex: 1, overflow: 'visible' }}>
                        {service.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="d-flex align-items-center mb-2 feature-item-premium" style={{
                            padding: '8px 12px',
                            transition: 'all 0.4s ease',
                            borderRadius: '12px',
                            background: 'rgba(255,255,255,0.7)',
                            border: '1px solid rgba(255,255,255,0.5)',
                            backdropFilter: 'blur(10px)'
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = 'rgba(255,255,255,0.9)';
                            e.currentTarget.style.transform = 'translateX(5px)';
                            e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.1)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = 'rgba(255,255,255,0.7)';
                            e.currentTarget.style.transform = 'translateX(0)';
                            e.currentTarget.style.boxShadow = 'none';
                          }}>
                            <div className="feature-icon-premium me-3" style={{
                              width: '28px',
                              height: '28px',
                              borderRadius: '8px',
                              background: 'linear-gradient(135deg, #28a745 0%, #20c997 50%, #17a2b8 100%)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              boxShadow: '0 6px 15px rgba(40, 167, 69, 0.4)',
                              transition: 'all 0.3s ease',
                              position: 'relative'
                            }}>
                              <FaCheckCircle style={{ fontSize: '12px', color: 'white' }} />
                              {/* Feature Icon Glow */}
                              <div style={{
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                width: '100%',
                                height: '100%',
                                background: 'linear-gradient(135deg, #28a745 0%, #20c997 50%, #17a2b8 100%)',
                                borderRadius: '12px',
                                filter: 'blur(6px)',
                                opacity: '0.3',
                                transform: 'translate(-50%, -50%)',
                                zIndex: -1
                              }}></div>
                            </div>
                            <span className="fw-semibold text-dark" style={{ 
                              fontSize: '1rem',
                              letterSpacing: '0.3px'
                            }}>{feature}</span>
                          </div>
                        ))}
                      </div>
                  
                      {/* Ultra Premium Button */}
                      <div style={{ marginTop: 'auto', paddingTop: '10px' }}>
                        <Button 
                          variant="outline-primary" 
                          className="w-100 fw-bold py-2 service-btn-premium"
                          style={{
                            border: '2px solid transparent',
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                            color: 'white',
                            transition: 'all 0.4s ease',
                            position: 'relative',
                            overflow: 'hidden',
                            boxShadow: '0 8px 25px rgba(102, 126, 234, 0.3)',
                            fontSize: '0.95rem',
                            letterSpacing: '0.3px',
                            borderRadius: '12px',
                            fontWeight: '600'
                          }}
                          onMouseEnter={(e) => {
                            e.target.style.transform = 'translateY(-3px)';
                            e.target.style.boxShadow = '0 12px 35px rgba(102, 126, 234, 0.5)';
                            e.target.style.background = 'linear-gradient(135deg, #764ba2 0%, #667eea 100%)';
                          }}
                          onMouseLeave={(e) => {
                            e.target.style.transform = 'translateY(0)';
                            e.target.style.boxShadow = '0 8px 25px rgba(102, 126, 234, 0.3)';
                            e.target.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
                          }}
                        >
                          <span style={{ position: 'relative', zIndex: 2 }}>
                            Explore Service
                            <FaArrowRight className="ms-2" />
                          </span>
                          {/* Premium Button Shimmer */}
                          <div className="btn-shimmer-premium" style={{
                            position: 'absolute',
                            top: 0,
                            left: '-100%',
                            width: '100%',
                            height: '100%',
                            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
                            transition: 'left 0.8s ease'
                          }}></div>
                          {/* Button Glow Effect */}
                          <div style={{
                            position: 'absolute',
                            top: '50%',
                            left: '50%',
                            width: '100%',
                            height: '100%',
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
                            filter: 'blur(8px)',
                            opacity: '0.3',
                            transform: 'translate(-50%, -50%)',
                            zIndex: -1
                          }}></div>
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {/* 3D Shadow Effect */}
                  <div className="card-3d-shadow" style={{
                    position: 'absolute',
                    top: '20px',
                    left: '20px',
                    right: '-20px',
                    bottom: '-20px',
                    background: 'linear-gradient(135deg, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.05) 100%)',
                    borderRadius: '24px 24px 24px 24px',
                    zIndex: -1,
                    filter: 'blur(20px)',
                    opacity: 0.6
                  }}></div>
                </div>
              </div>
            </Col>
          ))}
        </Row>

        {/* Call to Action Section */}
        <Row className="text-center mb-5" data-aos="fade-up">
          <Col lg={8} className="mx-auto">
            <div className="p-5 rounded-4 shadow-lg" style={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              position: 'relative',
              overflow: 'hidden',
              transform: `translateY(${scrollY * 0.03}px)`,
              border: '2px solid rgba(255,255,255,0.2)',
              backdropFilter: 'blur(20px)'
            }}>
              <div className="position-absolute top-0 end-0 w-100 h-100" style={{
                background: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Cdefs%3E%3Cpattern id=\'grid\' width=\'20\' height=\'20\' patternUnits=\'userSpaceOnUse\'%3E%3Cpath d=\'M 20 0 L 0 0 0 20\' fill=\'none\' stroke=\'rgba(255,255,255,0.1)\' stroke-width=\'0.5\'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width=\'100\' height=\'100\' fill=\'url(%23grid)\'/%3E%3C/svg%3E")',
                opacity: 0.3
              }}></div>
              
              <div className="position-relative" style={{ zIndex: 2 }}>
                <h3 className="fw-bold mb-3 fs-2">Ready to Scale Your Business?</h3>
                <p className="lead mb-4 opacity-90">
                  Join hundreds of successful businesses that have transformed their operations 
                  with our innovative software solutions. Let's discuss your project today!
                </p>
                <div className="d-flex flex-wrap justify-content-center gap-3">
                  <Button 
                    size="lg" 
                    className="fw-bold px-5 py-3 rounded-pill"
                    style={{
                      background: 'linear-gradient(45deg, #FFD700, #FFA500)',
                      border: 'none',
                      boxShadow: '0 8px 25px rgba(255, 215, 0, 0.4)',
                      transition: 'all 0.3s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.transform = 'translateY(-3px)';
                      e.target.style.boxShadow = '0 12px 35px rgba(255, 215, 0, 0.6)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.transform = 'translateY(0)';
                      e.target.style.boxShadow = '0 8px 25px rgba(255, 215, 0, 0.4)';
                    }}
                    onClick={() => scrollToSection('contact')}
                  >
                    Start Your Project
                    <FaArrowRight className="ms-2" />
                  </Button>
                  <Button 
                    variant="outline-light" 
                    size="lg" 
                    className="fw-bold px-5 py-3 rounded-pill"
                    style={{
                      border: '2px solid rgba(255,255,255,0.8)',
                      backdropFilter: 'blur(10px)',
                      transition: 'all 0.3s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.background = 'rgba(255,255,255,0.1)';
                      e.target.style.transform = 'translateY(-3px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.background = 'transparent';
                      e.target.style.transform = 'translateY(0)';
                    }}
                    onClick={() => scrollToSection('projects')}
                  >
                    View Our Portfolio
                  </Button>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Services;
