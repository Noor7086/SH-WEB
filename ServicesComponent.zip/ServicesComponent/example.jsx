import React from 'react';
import Services from './Services';
import './Services.css';

// Example usage of the Services component
function App() {
  return (
    <div className="App">
      {/* You can add other components here */}
      
      {/* Services Component */}
      <Services />
      
      {/* You can add other components here */}
    </div>
  );
}

export default App;
